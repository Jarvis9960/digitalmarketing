import React from "react";
import "../css/footer.css";

function Footer() {
  return (
    <div className="footer">
      <div className="footer1">
        <h1>Exeligo Innovations</h1>
        <p>
          Lorem ipsum dolor sit amet
          <p>Lorem ipsum dolor sit.</p>
        </p>
        <img src="" alt="" />
      </div>
      <div className="footer1">
        <h1>Address</h1>
        <p>LCatalyst Techno LLC 701 </p>
        <p>Tillery Street Unit 12</p>
        <p>2174 Austin,</p>
        <h1>ph:-7865432445</h1>
        <h1>email:-jyot@gmail.com</h1>
      </div>
      <div className="footer1">
        <h1>Our Menu</h1>
        <ul>
          <li>home</li>
          <li>About Us</li>
          <li>Services</li>
          <li>blog</li>
        </ul>
      </div>
      <div className="footer1">
        <h1>Top Links</h1>
        <ul>
          <li>GDPR Policy</li>
          <li>Term of Business</li>
          <li>Refund Policy</li>
          <li>Privacy Policy</li>
        </ul>
      </div>
    
    </div>
  );
}

export default Footer;
